package cucumber.runner;

import cucumber.stepdef.Hooksimplementation;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/cucumber/features",
glue={"cucumber/stepdef","BaseClass"}, monochrome=true
		)
public class ExecutionClass extends Hooksimplementation{
 
}

